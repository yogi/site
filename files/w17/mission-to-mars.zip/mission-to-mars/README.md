# Mission to Mars Chrome App

## Install Chrome App

Go to Chrome's Tools -> Extensions then click "Load unpacked extension...". Then click on Launch to get it working.

## APIs

* [Serial API](http://developer.chrome.com/trunk/apps/app.hardware.html#serial)
