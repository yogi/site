
onload = function() {
    setupSerialComms();
    setupWorld();
};

